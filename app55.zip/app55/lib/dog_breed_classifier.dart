import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:tflite_flutter_helper/tflite_flutter_helper.dart';

class DogBreedClassifier {
  Interpreter? _interpreter;
  bool isInitialized = false;

  /// Initializes the TFLite interpreter.
  Future<void> initialize() async {
    if (isInitialized) {
      print("Interpreter is already initialized.");
      return;
    }

    try {
      print("Loading TFLite model...");
      _interpreter = await Interpreter.fromAsset('dog_breed_classifier_mobilenetv2.tflite');
      isInitialized = true;
      print("TFLite model loaded successfully.");
    } catch (e) {
      print("Failed to load TFLite model: $e");
      throw Exception("Interpreter initialization failed: $e");
    }
  }

  /// Classifies an image and returns the predicted dog breed.
  Future<String?> classifyImage(File imageFile, List<String> dogBreeds) async {
    if (!isInitialized || _interpreter == null) {
      print("Interpreter not initialized.");
      throw Exception("Interpreter not initialized.");
    }

    try {
      print("Reading and preprocessing the image...");
      final Uint8List imageBytes = await imageFile.readAsBytes();
      final img.Image? image = img.decodeImage(imageBytes);

      if (image == null) {
        throw Exception("Unable to decode image.");
      }

      // Resize the image to match the input size of the model
      final img.Image resizedImage = img.copyResize(image, width: 224, height: 224);

      // Convert image to tensor buffer
      TensorImage tensorImage = TensorImage(TfLiteType.float32);
      tensorImage.loadImage(resizedImage);

      // Normalize pixel values to [-1, 1]
      final ImageProcessor imageProcessor = ImageProcessorBuilder()
          .add(ResizeOp(224, 224, ResizeMethod.BILINEAR))
          .add(NormalizeOp(127.5, 127.5))
          .build();
      tensorImage = imageProcessor.process(tensorImage);

      // Prepare the output buffer
      final outputBuffer = TensorBuffer.createFixedSize(
        [_interpreter!.getOutputTensor(0).shape[1]],
        TfLiteType.float32,
      );

      print("Running inference...");
      // Run inference
      _interpreter!.run(tensorImage.buffer, outputBuffer.buffer);

      // Get the probabilities
      final probabilities = outputBuffer.getDoubleList();
      final maxIndex = probabilities.indexOf(probabilities.reduce((a, b) => a > b ? a : b));

      print("Classification successful. Predicted breed: ${dogBreeds[maxIndex]}");
      return dogBreeds[maxIndex];
    } catch (e) {
      print("Error during classification: $e");
      throw Exception("Classification failed: $e");
    }
  }

  /// Releases interpreter resources.
  void close() {
    _interpreter?.close();
    _interpreter = null;
    isInitialized = false;
    print("Interpreter resources released.");
  }
}
