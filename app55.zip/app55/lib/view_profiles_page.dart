import 'package:flutter/material.dart';
import 'package:app5/firestore_service.dart'; // Replace 'app5' with your project name
import 'package:app5/dog_profile.dart'; // Replace 'app5' with your project name

class ViewProfilesPage extends StatelessWidget {
  const ViewProfilesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dog Profiles'),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<List<DogProfile>>(
        future: FirestoreService().getDogProfiles(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No profiles found.'));
          }

          final profiles = snapshot.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: profiles.length,
            itemBuilder: (context, index) {
              final profile = profiles[index];
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(
                      profile.name[0].toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  title: Text(profile.name, style: const TextStyle(fontSize: 18)),
                  subtitle: Text(
                      'Breed: ${profile.breed}\nAge: ${profile.age} years',
                      style: const TextStyle(fontSize: 14)),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit, color: Colors.deepPurple),
                    onPressed: () {
                      // Handle edit functionality here (optional)
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}