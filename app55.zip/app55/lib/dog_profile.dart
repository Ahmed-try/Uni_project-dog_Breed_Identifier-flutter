class DogProfile {
  String name;
  String breed;
  int age;

  DogProfile({required this.name, required this.breed, required this.age});

  // Convert to a Firestore-compatible map
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'breed': breed,
      'age': age,
    };
  }

  // Create from Firestore map
  factory DogProfile.fromMap(Map<String, dynamic> map) {
    return DogProfile(
      name: map['name'] ?? '',
      breed: map['breed'] ?? '',
      age: map['age'] ?? 0,
    );
  }
}