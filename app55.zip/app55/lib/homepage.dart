import 'dart:ui';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dog_breed_classifier.dart';
import 'chat.dart';
import 'dog_profile.dart';
import 'firestore_service.dart';
import 'view_profiles_page.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DogBreedClassifier _classifier = DogBreedClassifier();
  File? _selectedImage;
  String? _predictedBreed;
  bool _isClassifierReady = false;
  bool _isDarkMode = false;

  final List<Map<String, String>> _faqs = [
    {
      'question': 'What are common health concerns for dogs?',
      'answer': 'Common concerns include dental disease, obesity, parasites, and skin infections.',
    },
    {
      'question': 'How much exercise does my dog need?',
      'answer': 'Exercise varies by breed. Smaller breeds need less, while working breeds require more.',
    },
    {
      'question': 'What should I feed my dog?',
      'answer': 'Dogs need a balanced diet. Consult your vet for specifics and avoid harmful foods.',
    },
    {
      'question': 'How often should I groom my dog?',
      'answer': 'Long-haired breeds need grooming every few days, while short-haired ones require less frequent grooming.',
    },
  ];

  final List<Map<String, String>> _dogProfiles = [];

  @override
  void initState() {
    super.initState();
    _initializeClassifier();
  }

  Future<void> _initializeClassifier() async {
    try {
      await _classifier.initialize();
      setState(() {
        _isClassifierReady = true;
      });
      print("Classifier initialized successfully.");
    } catch (e) {
      print("Error initializing classifier: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error initializing classifier: ${e.toString()}')),
      );
    }
  }

  void _signOut() async {
    try {
      await _auth.signOut();
      Navigator.of(context).pushReplacementNamed('/login');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error signing out: ${e.toString()}')),
      );
    }
  }

  Future<void> _pickImage() async {
    if (!_isClassifierReady) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Classifier is not initialized. Please try again later.')),
      );
      return;
    }

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
        _predictedBreed = null; // Reset previous prediction
      });

      final dogBreeds = <String>[  'affenpinscher', 'afghan_hound', 'african_hunting_dog', 'airedale', 'american_staffordshire_terrier',
        'appenzeller', 'australian_terrier', 'basenji', 'basset', 'beagle', 'bedlington_terrier',
        'bernese_mountain_dog', 'black-and-tan_coonhound', 'blenheim_spaniel', 'bloodhound', 'bluetick',
        'border_collie', 'border_terrier', 'borzoi', 'boston_bull', 'bouvier_des_flandres', 'boxer',
        'brabancon_griffon', 'briard', 'brittany_spaniel', 'bull_mastiff', 'cairn', 'cardigan',
        'chesapeake_bay_retriever', 'chihuahua', 'chow', 'clumber', 'cocker_spaniel', 'collie',
        'curly-coated_retriever', 'dandie_dinmont', 'dhole', 'dingo', 'doberman', 'english_foxhound',
        'english_setter', 'english_springer', 'entlebucher', 'eskimo_dog', 'flat-coated_retriever',
        'french_bulldog', 'german_shepherd', 'german_short-haired_pointer', 'giant_schnauzer',
        'golden_retriever', 'gordon_setter', 'great_dane', 'great_pyrenees', 'greater_swiss_mountain_dog',
        'groenendael', 'ibizan_hound', 'irish_setter', 'irish_terrier', 'irish_water_spaniel',
        'irish_wolfhound', 'italian_greyhound', 'japanese_spaniel', 'keeshond', 'kelpie',
        'kerry_blue_terrier', 'komondor', 'kuvasz', 'labrador_retriever', 'lakeland_terrier', 'leonberg',
        'lhasa', 'malamute', 'malinois', 'maltese_dog', 'mexican_hairless', 'miniature_pinscher',
        'miniature_poodle', 'miniature_schnauzer', 'newfoundland', 'norfolk_terrier', 'norwegian_elkhound',
        'norwich_terrier', 'old_english_sheepdog', 'otterhound', 'papillon', 'pekinese', 'pembroke',
        'pomeranian', 'pug', 'redbone', 'rhodesian_ridgeback', 'rottweiler', 'saint_bernard', 'saluki',
        'samoyed', 'schipperke', 'scotch_terrier', 'scottish_deerhound', 'sealyham_terrier',
        'shetland_sheepdog', 'shih-tzu', 'siberian_husky', 'silky_terrier', 'soft-coated_wheaten_terrier',
        'staffordshire_bullterrier', 'standard_poodle', 'standard_schnauzer', 'sussex_spaniel',
        'tibetan_mastiff', 'tibetan_terrier', 'toy_poodle', 'toy_terrier', 'vizsla', 'walker_hound',
        'weimaraner', 'welsh_springer_spaniel', 'west_highland_white_terrier', 'whippet',
        'wire-haired_fox_terrier', 'yorkshire_terrier'
      ];

      try {
        final breed = await _classifier.classifyImage(_selectedImage!, dogBreeds);
        setState(() {
          _predictedBreed = breed;
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error during classification: ${e.toString()}')),
        );
      }
    }
  }

  void _addDogProfile() {
    showDialog(
      context: context,
      builder: (context) {
        // Controllers for input fields
        final TextEditingController nameController = TextEditingController();
        final TextEditingController breedController = TextEditingController();
        final TextEditingController ageController = TextEditingController();

        return AlertDialog(
          title: const Text("Add Dog Profile"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: "Name"),
              ),
              TextField(
                controller: breedController,
                decoration: const InputDecoration(labelText: "Breed"),
              ),
              TextField(
                controller: ageController,
                decoration: const InputDecoration(labelText: "Age"),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), // Close the dialog
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                // Retrieve user inputs
                final String name = nameController.text.trim();
                final String breed = breedController.text.trim();
                final int? age = int.tryParse(ageController.text.trim());

                // Validate inputs
                if (name.isEmpty || breed.isEmpty || age == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Please fill in all fields!")),
                  );
                  return;
                }

                // Create DogProfile object
                DogProfile dogProfile = DogProfile(
                  name: name,
                  breed: breed,
                  age: age,
                );

                // Save the profile to Firestore
                await FirestoreService().saveDogProfile(dogProfile);

                // Close the dialog and show a confirmation
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Dog profile added successfully!")),
                );
              },
              child: const Text("Add"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final User? user = _auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dog Breed Identifier"),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
            icon: Icon(_isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () {
              setState(() {
                _isDarkMode = !_isDarkMode;
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: const Icon(Icons.person, color: Colors.deepPurple),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    user != null ? user.email ?? "Guest User" : "Guest User",
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.pets),
              title: const Text("Add Dog Profile"),
              onTap: _addDogProfile,
            ),
            ListTile(
              leading: const Icon(Icons.list),
              title: const Text("View Dog Profiles"),
              onTap: () {
                Navigator.pop(context); // Close the drawer
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ViewProfilesPage()), // Navigate to the new page
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat),
              title: const Text("Chat with Us"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ChatScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/homepage.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(color: Colors.black.withOpacity(0.3)),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_selectedImage != null)
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(
                            _selectedImage!,
                            height: 200,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (_predictedBreed != null)
                        Container(
                          padding: const EdgeInsets.all(16.0),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            children: [
                              const Text(
                                "Predicted Breed",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                _predictedBreed!,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.deepPurple,
                                ),
                              ),
                            ],
                          ),
                        ),
                      const SizedBox(height: 20),
                    ],
                  )
                else
                  const Text(
                    "Upload an image to classify your dog's breed.",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                const SizedBox(height: 20),
                Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    leading: Icon(Icons.pets, color: Colors.deepPurple),
                    title: const Text("Identify Your Dog's Breed"),
                    subtitle: const Text("Upload an image to identify your dog's breed."),
                    onTap: _pickImage,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Frequently Asked Questions",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.yellow,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: PageView.builder(
                    itemCount: _faqs.length,
                    itemBuilder: (context, index) {
                      final faq = _faqs[index];
                      return Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              faq['question']!,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              faq['answer']!,
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => const ChatScreen()),
                    );
                  },
                  icon: const Icon(Icons.chat, color: Colors.white),
                  label: const Text("Chat with Us"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    textStyle: const TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
