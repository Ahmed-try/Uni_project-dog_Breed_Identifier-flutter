import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _userInputController = TextEditingController();

  static const String apiKey = "AIzaSyDThRn0mnwiJ4mlqhqUhS6wLyAcYb6L2hk";
  final GenerativeModel _model =
  GenerativeModel(model: 'gemini-pro', apiKey: apiKey);
  final List<Message> _messages = [];

  final List<String> _healthKeywords = [
    "health", "exercise", "diet", "grooming", "veterinarian", "disease",
    "illness", "food", "care", "medicines", "symptoms", "treatment",
    "vaccination", "behavior", "nutrition", "injury", "first aid",
    "puppy care", "kitten care", "pet training", "hygiene", "parasites",
    "deworming", "flea treatment", "skin issues", "allergies", "paw care",
    "emergency care", "hydration", "behavior problems", "obedience",
    "weight management", "overfeeding", "underfeeding", "pet anxiety",
    "ear cleaning", "dental care", "oral hygiene", "nail trimming",
    "spaying", "neutering", "breeding", "puppy vaccinations", "senior pets",
    "arthritis", "mobility", "diabetes", "heart health", "lungs",
    "respiratory issues", "worms", "ticks", "scratching", "itching",
    "redness", "discharge", "appetite loss", "lethargy", "puppy teething",
    "kitten teething", "claw issues", "fur shedding", "coat care",
    "bathing", "shampoo", "pet-safe products", "house training", "crate training",
    "socialization", "training tips", "pet safe foods", "toxic foods",
    "poisoning", "pet-proofing", "microchipping", "ID tags", "collars",
    "leash training", "exercise routines", "mental stimulation",
    "toys", "safe toys", "chewing", "biting", "aggression",
    "fear", "phobias", "separation anxiety", "thunderstorm anxiety",
    "car rides", "travel tips", "boarding", "pet sitters", "dietary supplements",
    "probiotics", "omega fatty acids", "joint health", "bone health",
    "eyes", "vision issues", "blindness", "ear mites", "anal glands",
    "digestive issues", "constipation", "diarrhea", "vomiting",
    "dehydration", "urinary tract", "bladder health", "kidney health",
    "liver health", "cancer", "tumors", "lumps", "infections",
    "antibiotics", "anti-inflammatory", "pain management", "post-surgery care",
    "vaccination schedule", "worm prevention", "pet insurance",
    "pet first aid kit", "emergency contact", "vet visits",
    "routine checkups", "pet loss", "grieving", "euthanasia",
    "new pet", "adoption", "foster care", "multi-pet household",
    "pet compatibility", "behavior adjustment", "environment enrichment",
    "chewing prevention", "boredom signs", "active play", "water safety",
    "swimming", "heatstroke prevention", "cold weather care",
    "holiday safety", "firework anxiety", "seasonal allergies"
  ];


  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _addInitialBotMessage();
  }

  void _addInitialBotMessage() {
    setState(() {
      _messages.add(Message(
        isUser: false,
        message: "Hi there! I'm here to help with your pet's health and care. How can I assist you today?",
        date: DateTime.now(),
      ));
    });
  }

  bool _isHealthRelated(String query) {
    for (final keyword in _healthKeywords) {
      if (query.toLowerCase().contains(keyword)) {
        return true;
      }
    }
    return false;
  }

  Future<void> sendMessage() async {
    final userMessage = _userInputController.text.trim();

    if (userMessage.isEmpty) {
      return;
    }

    setState(() {
      _messages.add(Message(
        isUser: true,
        message: userMessage,
        date: DateTime.now(),
      ));
      _isTyping = true;
    });

    _userInputController.clear();

    if (!_isHealthRelated(userMessage)) {
      setState(() {
        _messages.add(Message(
          isUser: false,
          message: "I specialize in pet health and care. Please ask something related to your pet's well-being.",
          date: DateTime.now(),
        ));
        _isTyping = false;
      });
      return;
    }

    try {
      final content = [Content.text(userMessage)];
      final response = await _model.generateContent(content);

      setState(() {
        _messages.add(Message(
          isUser: false,
          message: response.text ?? "I'm sorry, I couldn't process your request. Try asking in a different way.",
          date: DateTime.now(),
        ));
        _isTyping = false;
      });
    } catch (e) {
      setState(() {
        _messages.add(Message(
          isUser: false,
          message: "An error occurred while processing your request. Please try again later.",
          date: DateTime.now(),
        ));
        _isTyping = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat with PawBot", style: TextStyle(color: Colors.white)),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepPurple, Colors.purpleAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: const DecorationImage(
            image: AssetImage('assets/pic.jpeg'), // Background image
            fit: BoxFit.cover,
          ),
          color: Colors.black.withOpacity(0.8),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
              child: ListView.builder(
                reverse: true,
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[_messages.length - 1 - index];
                  return MessageBubble(
                    isUser: message.isUser,
                    message: message.message,
                    date: DateFormat('HH:mm').format(message.date),
                  );
                },
              ),
            ),
            if (_isTyping) TypingIndicator(),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _userInputController,
                      decoration: InputDecoration(
                        hintText: 'Ask about your pet\'s health...',
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  FloatingActionButton(
                    onPressed: sendMessage,
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Message {
  final bool isUser;
  final String message;
  final DateTime date;

  Message({
    required this.isUser,
    required this.message,
    required this.date,
  });
}

class MessageBubble extends StatelessWidget {
  final bool isUser;
  final String message;
  final String date;

  const MessageBubble({
    Key? key,
    required this.isUser,
    required this.message,
    required this.date,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.all(15),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.7,
        ),
        decoration: BoxDecoration(
          color: isUser ? Colors.deepPurple : Colors.grey.shade200,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(15),
            topRight: const Radius.circular(15),
            bottomLeft: isUser ? const Radius.circular(15) : Radius.zero,
            bottomRight: isUser ? Radius.zero : const Radius.circular(15),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 5,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
          isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(
              message,
              style: TextStyle(
                fontSize: 16,
                color: isUser ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              date,
              style: TextStyle(
                fontSize: 12,
                color: isUser ? Colors.white70 : Colors.black54,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TypingIndicator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
      child: Row(
        children: const [
          CircleAvatar(radius: 5, backgroundColor: Colors.grey),
          SizedBox(width: 5),
          CircleAvatar(radius: 5, backgroundColor: Colors.grey),
          SizedBox(width: 5),
          CircleAvatar(radius: 5, backgroundColor: Colors.grey),
        ],
      ),
    );
  }
}
