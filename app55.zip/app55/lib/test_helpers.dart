import 'package:firebase_core/firebase_core.dart';

Future<void> initializeFirebaseForTesting() async {
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "fake_api_key",
      appId: "fake_app_id",
      messagingSenderId: "fake_sender_id",
      projectId: "fake_project_id",
    ),
  );
}