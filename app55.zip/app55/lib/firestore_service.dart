import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dog_profile.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> saveDogProfile(DogProfile profile) async {
    try {
      final User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Reference the 'dogProfiles' sub-collection
        CollectionReference dogProfiles = _firestore
            .collection('users')
            .doc(userId)
            .collection('dogProfiles');

        // Add the dog profile
        await dogProfiles.add(profile.toMap());
        print('Dog profile saved successfully!');
      } else {
        print('User is not logged in.');
      }
    } catch (e) {
      print('Error saving dog profile: $e');
    }
  }
  Future<List<DogProfile>> getDogProfiles() async {
    List<DogProfile> profiles = [];
    try {
      final User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Fetch all documents in the 'dogProfiles' sub-collection
        QuerySnapshot snapshot = await _firestore
            .collection('users')
            .doc(userId)
            .collection('dogProfiles')
            .get();

        // Convert each document to a DogProfile object
        profiles = snapshot.docs.map((doc) {
          return DogProfile.fromMap(doc.data() as Map<String, dynamic>);
        }).toList();
      }
    } catch (e) {
      print('Error retrieving dog profiles: $e');
    }
    return profiles;
  }

}