import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Create a mock class for FirebaseAuth
class MockFirebaseAuth extends Mock implements FirebaseAuth {}

void main() {
  group('FirebaseAuth signOut', () {
    test('User is signed out successfully', () async {
      // Arrange: Set up the mock FirebaseAuth instance
      final mockAuth = MockFirebaseAuth();

      // Mock the signOut method to return a Future<void>
      when(mockAuth.signOut()).thenAnswer((_) async => Future.value());

      // Act: Call the signOut method
      await mockAuth.signOut();

      // Assert: Verify that signOut was called exactly once
      verify(mockAuth.signOut()).called(1);
    });
  });
}