import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:app5/dog_profile.dart';
import 'package:app5/firestore_service.dart';

// Mock class for FirestoreService
class MockFirestoreService extends Mock implements FirestoreService {}

void main() {
  group('Add Dog Profile Dialog', () {
    testWidgets('saves profile correctly', (WidgetTester tester) async {
      // Arrange
      final mockFirestoreService = MockFirestoreService();
      const testName = 'Buddy';
      const testBreed = 'Golden Retriever';
      const testAge = 3;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text("Add Dog Profile"),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextField(
                            key: const Key('nameField'),
                            decoration: const InputDecoration(labelText: "Name"),
                          ),
                          TextField(
                            key: const Key('breedField'),
                            decoration: const InputDecoration(labelText: "Breed"),
                          ),
                          TextField(
                            key: const Key('ageField'),
                            decoration: const InputDecoration(labelText: "Age"),
                            keyboardType: TextInputType.number,
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Cancel"),
                        ),
                        TextButton(
                          onPressed: () {
                            final name = (tester.firstWidget(find.byKey(const Key('nameField'))) as TextField).controller?.text;
                            final breed = (tester.firstWidget(find.byKey(const Key('breedField'))) as TextField).controller?.text;
                            final ageText = (tester.firstWidget(find.byKey(const Key('ageField'))) as TextField).controller?.text;
                            final age = int.tryParse(ageText ?? '');

                            if (name != null && breed != null && age != null) {
                              final profile = DogProfile(
                                name: name,
                                breed: breed,
                                age: age,
                              );
                              mockFirestoreService.saveDogProfile(profile);
                              Navigator.pop(context);
                            }
                          },
                          child: const Text("Add"),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text("Open Dialog"),
              ),
            ),
          ),
        ),
      );

      // Act
      await tester.tap(find.text("Open Dialog")); // Tap the ElevatedButton
      await tester.pumpAndSettle();

      await tester.enterText(find.byKey(const Key('nameField')), testName);
      await tester.enterText(find.byKey(const Key('breedField')), testBreed);
      await tester.enterText(find.byKey(const Key('ageField')), '$testAge');
      await tester.tap(find.text("Add")); // Tap the "Add" button
      await tester.pumpAndSettle();

      // Assert
      verify(mockFirestoreService.saveDogProfile(
        argThat(
          predicate((profile) =>
          profile is DogProfile &&
              profile.name == testName &&
              profile.breed == testBreed &&
              profile.age == testAge),
        ),
      )).called(1);
    });
  });
}